# O Presente do Nilo

**Período:** Antiguidade  
**Tema:** Egito Antigo

---

Nefertari despertou antes do nascer do sol, quando as primeiras luzes douradas ainda não tocavam as pedras calcárias das grandes pirâmides de Gizé. Como escriba real, seu dia começava cedo, muito antes que o calor escaldante do deserto tomasse conta das terras negras do Egito.

A jovem de vinte e cinco anos pertencia a uma família de escribas — uma das profissões mais respeitadas da sociedade egípcia. Seu pai, Amenhotep, havia lhe ensinado desde criança os segredos dos hieróglifos, a escrita sagrada dos deuses. Nefertari recordava-se de suas mãos infantis tremendo ao segurar o calcário e o pincel de junco, mergulhando na tinta preta feita de carvão e água. Hoje, seus traços eram firmes e precisos, capazes de registrar desde os decretos do faraó até os cálculos de impostos dos camponeses.

Ao sair de sua modesta casa de adobe em Tebas, Nefertari caminhou em direção ao palácio real. As ruas já fervilhavam de atividade: mercadores ofereciam peixes frescos do Nilo, mulheres carregavam ânforas de água na cabeça com graça surpreendente, e crianças brincavam às margens do rio sagrado. O Nilo era o coração pulsante do Egito — suas águas generosas, que transbordavam anualmente nas cheias, depositavam uma lama fértil que permitia colheitas abundantes nas terras negras, o *kemet*, como os egípcios chamavam seu país.

— Nefertari! — chamou uma voz conhecida. Era Khaemweset, um jovem sacerdote de Osíris, o deus do submundo e dos mortos. — O faraó convoca os escribas para uma tarefa especial.

No palácio, a grandiosidade da civilização egípcia se revelava em cada detalhe. Colunas de pedra sustentavam tetos pintados com cenas de batalhas e oferendas aos deuses. Estátuas monumentais guardavam os corredores, e o cheiro de incenso e mirra impregnava o ar. O faraó Ramsés III, considerado a encarnação viva do deus Hórus, governava com poder absoluto — era simultaneamente chefe militar, supremo sacerdote e juiz máximo.

— Nefertari — disse o vizir, o segundo homem mais poderoso do reino, responsável pela administração da justiça e das finanças. — Sua excelência deseja que você registre os detalhes da construção de uma nova tumba no Vale dos Reis. Ovizir admirava o trabalho meticuloso da escriba, uma das poucas mulheres a ocupar tal posição.

O Egito era uma sociedade estratificada, onde cada pessoa tinha seu lugar definido. No topo estava o faraó, seguido pelos nobres e sacerdotes. Abaixo vinham os escribas, como Nefertari, que formavam a elite intelectual. Depois, os artesãos, comerciantes e, finalmente, os camponeses e servos que trabalhavam nas terras dos templos e nobres. Apesar da hierarquia rígida, o sistema de *ma'at* — o conceito de ordem, justiça e harmonia — permeava toda a sociedade, garantindo que cada um cumprisse seu papel para manter o equilíbrio cósmico.

Nos dias seguintes, Nefertari viajou ao Vale dos Reis, na margem ocidental do Nilo, onde os faraós eram sepultados em tumbas escavadas nas rochas. Diferentemente das pirâmides monumentais do Império Antigo, essas tumbas eram escondidas para evitar saques, embora nem sempre com sucesso.

A mumificação fascinava Nefertari. Os egípcios acreditavam que a preservação do corpo era essencial para a vida após a morte. Os embalsamadores removiam os órgãos internos, deixando apenas o coração — considerado a sede da inteligência e da alma — e os colocavam em vasos canopos, protegidos pelos quatro filhos de Hórus. O corpo era então coberto com natrão, um sal natural que desidratava os tecidos, e envolto em faixas de linho, entre as quais eram colocados amuletos protetores. O processo durava setenta dias e era acessível apenas aos mais ricos.

Enquanto registrava os hieróglifos nas paredes da tumba, Nefertari contemplava as cenas pintadas: o faraó sendo julgado por Osíris, com Anúbis pesando seu coração contra a pena da verdade, símbolo de Ma'at. Se o coração fosse mais pesado que a pena, significava que o morto cometera más ações e seria devorado por Ammit, a deusa crocodilo. Caso contrário, alcançaria o paraíso eterno, os Campos de Iaru.

A religião egípcia era politeísta, com centenas de divindades. Rá, o deus sol, navegava pelo céu durante o dia e pelo submundo à noite, enfrentando a serpente Apópis para que o sol renascesse. Ísis, a grande mágica, havia ressuscitado Osíris, seu esposo, tornando-se símbolo de amor conjugal e proteção. Cada cidade tinha seus deuses protetores, e os templos eram as casas dessas divindades na Terra.

— Os deuses nos deram tudo — disse Khaemweset, observando Nefertari trabalhar. — O Nilo, as cheias, as colheitas. Em troca, oferecemos ma'at.

Nefertari concordou. O faraó, como intermediário entre os deuses e os homens, realizava rituais diários nos templos para manter a ordem cósmica. O fracasso desses rituais poderia trazer caos, fome e desordem.

Ao retornar a Tebas, Nefertari passou pelas margens do Nilo, onde trabalhadores construíam uma nova pirâmide menor para um nobre. As grandes pirâmides de Gizé, erguidas milênios antes, eram testemunhos do poder e da organização do Egito Antigo. Milhares de trabalhadores — não escravos, como muitos pensavam, mas camponeses que prestavam serviço durante as cheias do Nilo — haviam transportado milhões de blocos de pedra por rampas e alavancas, construindo monumentos que desafiavam o tempo.

Aquela noite, Nefertari contemplou as estrelas do deserto. O Egito era uma dádiva do Nilo, como dissera o historiador grego Heródoto séculos mais tarde. Tudo — a agricultura, a escrita, a religião, a arquitetura — girava em torno do rio sagrado. E ela, como escriba, tinha o privilégio de registrar essa civilização extraordinária para a eternidade.

Seus hieróglifos perdurariam por milênios, contando histórias de faraós, deuses e de um povo que, entre desertos e cheias, construiu uma das mais grandiosas civilizações da humanidade.

---

**Contexto Histórico para o ENEM:**

- **Rio Nilo:** Fundamental para a civilização egípcia, fornecia água, alimento e solo fértil através das cheias anuais
- **Sociedade estratificada:** Faraó, nobres/sacerdotes, escribas, artesãos/comerciantes, camponeses/servos
- **Pirâmides:** Tumbas reais do Império Antigo, símbolos de poder e crença na vida após a morte
- **Mumificação:** Processo de preservação corporal essencial para a vida eterna segundo a religião egípcia
- **Hieróglifos:** Sistema de escrita sagrada, domínio dos escribas
- **Politeísmo:** Múltiplos deuses (Rá, Osíris, Ísis, Hórus, Anúbis) com funções específicas
- **Ma'at:** Conceito de ordem, justiça e harmonia cósmica
- **Faraó:** Governante absoluto, considerado encarnação de Hórus e intermediário entre deuses e homens
