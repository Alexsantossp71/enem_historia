# O Tempo dos Coronéis

## Um Conto da República Velha Brasileira (1889-1930)

---

O sol de ouro despontava sobre as plantações de café quando Coronel Chico montou seu cavalo baio, preparando-se para mais uma jornada de trabalho político na pequena cidade de Ribeirão do Sul, no interior paulista. O ano era 1922, e o Brasil vivia os últimos anos da chamada República Velha — um período em que o poder se concentrava nas mãos dos grandes produtores de café e dos chefes políticos locais.

Francisco "Chico" Alves era conhecido em toda a região como o "Coronel". Não era militar de carreira — o título era apenas uma designação honorífica concedida pela Guarda Nacional a homens de prestígio e poder econômico. Mas o respeito que inspirava nas pessoas era real e profundo. Dono de vastas terras, dono do único armazém da cidade, dono da pedra de açúcar e dono das terras onde moravam seus "agregados", Coronel Chico era a autoridade máxima em Ribeirão do Sul.

— Zé, prepare os homens — ordenou ao seu capanga de confiança. — Hoje vamos até a sede do município. É dia de alistamento eleitoral.

Naquele tempo, o Brasil era governado sob um sistema que os críticos chamavam de "política dos governadores". A aliança entre São Paulo e Minas Gerais — os dois estados mais ricos e populosos — garantia a alternância na presidência da República. Era a famosa "política do café com leite": os paulistas, representando os interesses dos barões do café, e os mineiros, defendendo os produtores de leite, revezavam-se no poder federal. Em troca do apoio do governo central, os estados garantiam seu domínio sobre a política local.

Coronel Chico caminhava pela rua principal da cidade, saudando os moradores com um aceno de chapéu. Todos retribuíam com reverência.

— Bom dia, seu Coronel! — dizia o padeiro.
— Deus o abençoe, Coronel! — exclamava a viúva que recebera terras para plantar.

Esse era o coronelismo: uma rede de relações pessoais em que o chefe político oferecia proteção, emprego e favores em troca de lealdade política. Os coronéis eram os elos entre o poder local e as oligarquias estaduais, garantindo que os votos necessários chegassem aos candidatos certos.

Ao chegar à porta do Cartório Eleitoral, Coronel Chico encontrou outros coronéis da região. Eles cumprimentaram-se com formalidade.

— Chico, ouvi dizer que este ano o Washington Luís é o candidato — comentou Coronel Justino, de uma cidade vizinha. — Mais um paulista na Presidência.

— É a vez de São Paulo, Justino. O Brasil precisa de homens que entendam de café — respondeu Chico, ajustando o chapéu. — Nossa riqueza vem do café, e o governo precisa proteger nossos interesses.

Washington Luís, paulista e ex-prefeito da capital, seria o sucessor de Epitácio Pessoa. A política do café com leite seguía seu curso, embora já mostrasse sinais de desgaste. Minas Gerais sentia-se preterida em algumas ocasiões, e o Rio Grande do Sul crescia em importância política.

No interior do cartório, o juiz eleitoral esperava os coronéis com um livro de alistamento aberto sobre a mesa. Havia poucos brasileiros que podiam votar — apenas homens alfabetizados, o que excluía a maior parte da população pobre e analfabeta. Mas entre os que podiam votar, quase todos estavam sob a tutela de algum coronel.

— Coronel Chico, quantos eleitores o senhor traz hoje? — perguntou o juiz.

— Trago vinte e três, doutor juiz. Todos bons homens, trabalhadores da minha fazenda e do meu comércio. Homens de bem.

Um a um, os eleitores foram apresentando-se. João da Silva, Sebastião Pereira, Antônio Gomes... Todos homens que trabalhavam para Coronel Chico ou moravam em suas terras. Todos sabiam exatamente em quem votar — não porque alguém lhes dissesse explicitamente, mas porque a rede de favores e obrigações tornava a escolha óbvia.

Era o "voto de cabresto": os coronéis controlavam os eleitores através de laços de dependência econômica, gratidão por favores recebidos ou medo de represálias. O voto não era secreto, e todos sabiam quem tinha votado em quem. Se um agregado ousasse votar contra as ordens do coronel, poderia perder suas terras, seu emprego, a proteção para sua família.

Ao fim do alistamento, Coronel Chico convidou os outros chefes políticos para um almoço em sua fazenda. Enquanto a carne de porco assava no fogão a lenha e a pinga corria, a conversa girava sobre política.

— O Bernardino Machado está levantando poeira em Minas — disse Coronel Justino. — Dizem que os mineiros estão descontentes com a hegemonia paulista.

— Que levantem poeira — respondeu Chico, servindo-se de feijão tropeiro. — Enquanto tivermos as urnas do interior sob controle, nada muda. O poder está aqui, nas mãos de quem conhece cada eleitor pelo nome.

Mas Coronel Chico, apesar de toda sua certeza, pressentia mudanças no ar. O Brasil urbanizava-se rapidamente. A industrialização crescera durante a Primeira Guerra Mundial, e uma nova classe operária surgia nas grandes cidades. Movimentos como o tenentismo — jovens oficiais do Exército que criticavam a corrupção eleitoral e exigiam reformas — ganhavam força. A Coluna Prestes cruzava o Brasil denunciando as oligarquias.

— Os tempos estão mudando, amigos — disse Chico, olhando para o horizonte onde as fileiras de cafeeiros se perdiam na distância. — Mas enquanto este país viver de café, nós, os homens do interior, teremos voz.

Anos depois, em 1930, a Revolução varreria o país, derrubando Washington Luís e pondo fim à República Velha. O sistema de coronelismo e voto de cabresto começaria a se esvair, embora suas raízes demorassem séculos para morrer completamente.

Coronel Chico viveria para ver tudo isso. E nas noites de saudade, sentado na varanda de sua fazenda, recordaria os tempos em que um aperto de mão e um pedido de voto eram suficientes para mover eleições e definir o destino do Brasil.

---

**Contexto Histórico:**

A República Velha (1889-1930) foi marcada pelo domínio das oligarquias cafeeiras, especialmente de São Paulo e Minas Gerais. O coronelismo era o sistema de poder local, onde chefes políticos controlavam a população através de favores e pressões. O voto de cabresto garantia que os coronéis entregassem os votos necessários aos candidatos das oligarquias estaduais e federais. Este sistema entrou em crise com a urbanização, industrialização e o movimento tenentista, culminando na Revolução de 1930.

---

*Palavras: 1.047*
