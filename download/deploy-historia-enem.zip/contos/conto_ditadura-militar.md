# Os Anos de Chumbo

**Período:** 1964-1985  
**Tema:** Ditadura Militar no Brasil

---

Fernando acordou sobressaltado com o som de passos no corredor. Seu coração disparou, mas logo percebeu que era apenas o vizinho descendo as escadas. "Ainda estou vivo", pensou, aliviado. Mas por quanto tempo?

Era março de 1970, seis anos após o golpe que derrubara o presidente João Goulart. Fernando, estudante de História na Universidade de São Paulo, havia se envolvido com o movimento estudantil desde os tempos do colégio. Aos 22 anos, seu nome já constava numa lista do DOPS — o Departamento de Ordem Política e Social, o temido órgão de repressão política.

— Você precisa sair do país, Fernando — disse Maria, sua irmã mais velha, servindo-lhe um café fraco na pequena cozinha do apartamento. — Não podemos arriscar mais. O Carlos foi preso semana passada.

Fernando estremeceu. Carlos, seu amigo de faculdade, havia sido levado por homens de terno escuro que diziam representar "a segurança nacional". Ninguém sabia onde ele estava. A família recebera apenas um telefonema anônimo informando que ele estava "à disposição das autoridades".

— Eu não vou fugir, Maria — respondeu Fernando, com a teimosia típica dos jovens que acreditam poder mudar o mundo. — O Brasil é meu país. Se todos partirem, quem vai lutar contra essa tirania?

Os anos que se seguiram ao golpe de 1964 haviam transformado o Brasil. O general Castelo Branco assumira a presidência, prometendo "restaurar a ordem". Em 1968, o governo endureceu ainda mais com a decretação do AI-5 — o Ato Institucional número cinco, que fechou o Congresso Nacional, suspendeu garantias constitucionais e instituiu a censura prévia a jornais, rádios e televisão.

— Você leu o jornal de hoje? — perguntou Fernando, mostrando uma manchete sobre a guerrilha do Araguaia. — Dizem que os guerrilheiros estão sendo eliminados. Mas ninguém menciona que estão sendo torturados e executados sumariamente.

Maria baixou os olhos. Ela sabia que o irmão tinha razão, mas também conhecia o perigo que ele corria. Os DOI-CODI — Destacamentos de Operações de Informações — haviam se tornado centros de tortura onde presos políticos eram submetidos a suplícios inimagináveis. Histórias sobre a "pau-de-arara", afogamentos simulados e choques elétricos circulavam em sussurros pelos corredores das universidades.

Fernando lembrava-se da noite em que participara de uma reunião clandestina num porão emprestado por um padre progressista. Discutiam como organizar a resistência, como denunciar as atrocidades do regime para o exterior.

— O povo brasileiro precisa saber a verdade — argumentara na ocasião. — A censura nos cala, mas não pode nos silenciar para sempre.

No entanto, a perseguição se intensificou. Em 1973, Fernando foi obrigado a se esconder. Mudou-se para uma casa simples na periferia, usando nome falso. Trabalhou como ajudante de pedreiro, carpinteiro, qualquer coisa que lhe permitisse sobreviver sem chamar atenção. Seus dias eram marcados pelo medo constante de ser reconhecido, de ser traído por um conhecido, de ver surgir à sua porta os homens do regime.

— Senhor Antônio — chamou-o o dono da padaria onde comprava pão todas as manhãs —, ouvi no rádio que o general Geisel prometeu uma abertura política. Que o Brasil vai voltar à democracia.

Fernando sorriu amargamente. O general Ernesto Geisel assumira a presidência em 1974, prometendo uma "abertura lenta, gradual e segura". Mas as palavras do regime não correspondiam à realidade. Em 1975, o jornalista Vladimir Herzog foi encontrado morto nas dependências do DOI-CODI de São Paulo. A versão oficial falava em suicídio, mas ninguém acreditava.

— A abertura existe no papel, Seu Zé — respondeu Fernando, usando o apelido que adotara. — Mas meus amigos ainda estão sendo presos. Ainda existem presos políticos neste país.

Os anos passaram lentamente. Fernando acompanhou de longe o movimento das Diretas Já, em 1984, quando milhões de brasileiros foram às ruas exigir eleições presidenciais diretas. A emenda Dante de Oliveira foi derrotada no Congresso, mas o clamor popular era irreversível.

Em 1985, finalmente, o Brasil elegeu indiretamente Tancredo Neves, o primeiro presidente civil após vinte e um anos de regime militar. Fernando, então com 37 anos, pôde finalmente sair das sombras.

— O Brasil mudou — disse ele a Maria, agora sentados no mesmo apartamento onde haviam conversado quinze anos antes. — Mas não podemos esquecer o que aconteceu. A memória é a nossa maior arma contra o esquecimento.

— Você perdeu seus melhores anos fugindo — respondeu Maria, com os olhos úmidos.

— Não perdi, irmã. Os anos de chumbo me ensinaram o valor da liberdade. E agora preciso contar essa história para que as novas gerações nunca deixem que isso aconteça novamente.

Fernando tornou-se professor. Em suas aulas, falava sobre a importância da democracia, sobre os perigos do autoritarismo, sobre o preço que tantos brasileiros pagaram para que hoje pudéssemos votar, nos expressar livremente, viver sem medo.

E sempre terminava suas aulas com a mesma frase:

— A história nos ensina que a liberdade não é um presente. É uma conquista diária. E a vocês, jovens, cabe a responsabilidade de nunca deixar que os anos de chumbo retornem.

---

## Contexto Histórico para Estudo

**Golpe de 1964:** Movimento militar que depôs o presidente João Goulart, iniciando o período ditatorial.

**AI-5 (1968):** Ato Institucional que endureceu o regime, suspendendo garantias constitucionais e institucionalizando a censura.

**Repressão:** Perseguição política, tortura e assassinato de opositores do regime por órgãos como DOPS e DOI-CODI.

**Guerrilha do Araguaia:** Movimento de resistência armada organizado pelo PCdoB, duramente reprimido pelo exército.

**Abertura Política:** Processo iniciado no governo Geisel (1974-1979), marcado pela "abertura lenta, gradual e segura".

**Diretas Já (1984):** Movimento popular que exigia eleições presidenciais diretas.

**Redemocratização (1985):** Fim do regime militar com a eleição indireta de Tancredo Neves.

---

*Conto histórico educativo para preparação ENEM - História do Brasil*
