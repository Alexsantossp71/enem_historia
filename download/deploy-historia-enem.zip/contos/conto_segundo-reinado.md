# O Império do Café

**Um conto sobre o Segundo Reinado (1840-1889)**

---

## Parte I – A Prosperidade do Vale

O ano era 1860, e as montanhas do Vale do Paraíba reverberavam com o aroma inconfundível do café. Na Fazenda Santa Rita, as terras férteis produziam os grãos que alimentavam o mundo e enriqueciam o Império do Brasil.

Luísa, com seus dezoito anos, observava da varanda da casa-grande os escravizados colhendo os frutos vermelhos que cobriam as encostas. Filha dos Barões de Santa Rita, ela cresceu cercada por toda a opulência que o "ouro verde" podia proporcionar: vestidos de seda francesa, piano inglês na sala de visitas, e jantares onde se discutia política com visitantes do Rio de Janeiro.

— Pai, o Imperador realmente virá à nossa região este ano? — perguntou Luísa, enquanto o Barão tomava seu café da manhã.

D. Pedro II, monarca culto e de hábitos modestos, percorria o país com frequência, interessado em conhecer as províncias e ouvir seus súditos. Sua figura alta, de barba branca e olhar penetrante, inspirava respeito mesmo entre os mais céticos.

— Sua Majestade tem grande interesse em conhecer as lavouras que sustentam nossa economia, minha filha. O café representa mais de sessenta por cento de nossas exportações. Somos os maiores produtores do mundo! — respondeu o Barão, com evidente orgulho.

Luísa sabia que aquela riqueza tinha um custo humano que a atormentava. Desde criança, presenciara as senzalas superlotadas, os castigos na fazenda vizinha, as famílias separadas pelo comércio de almas. Algo em seu coração clamava por justiça.

---

## Parte II – A Lei do Ventre Livre

Em 28 de setembro de 1871, Luísa estava no Rio de Janeiro quando a notícia se espalhou pelas ruas: a Princesa Isabel, regente na ausência do pai, havia sancionado a Lei do Ventre Livre.

— Finalmente! — exclamou Luísa para sua tia, que a olhou com reprovação.

— Cuidado com essas ideias, menina. Seu pai não aprovaria.

A lei declarava livres os filhos de mulheres escravizadas que nascessem a partir daquela data. Para Luísa, representava um primeiro passo, ainda que tímido, rumo ao fim da escravidão.

Quando retornou à fazenda, encontrou seu pai furioso discutindo com outros fazendeiros na sala principal.

— Essa lei destruirá nossas propriedades! Como vamos manter a produção sem ampliar a força de trabalho? — gritava um dos visitantes.

O Barão de Santa Rita, porém, permanecia em silêncio, pensativo. Ele via o que muitos não queriam ver: os ventos da história sopravam em outra direção. A Inglaterra pressionava pelo fim do tráfico e da escravidão; o movimento abolicionista ganhava força nas cidades; e os próprios escravizados resistiam de todas as formas possíveis.

— Talvez seja hora de diversificarmos, — disse o Barão por fim. — O café do Vale está esgotando as terras. O Oeste Paulista, com sua terra roxa, representa o futuro. E lá, os imigrantes europeus já substituem os cativos.

Luísa percebeu que seu pai, homem pragmático, antecipava mudanças que viriam inevitavelmente.

---

## Parte III – A Guerra do Paraguai

Os anos seguintes trouxeram notícias sombrias. Desde 1864, o Brasil envolvera-se na maior guerra da história da América do Sul. O conflito contra o Paraguai de Solano López consumia vidas e recursos do Império.

— Dizem que nossos soldados morrem aos milhares — relatou um viajante à mesa dos Barões. — As condições são terríveis. Cólera, fome, e um inimigo que luta até o último homem.

Luísa lembrou-se de Antônio, filho de uma das escravas da fazenda, que fora enviado ao fronte em troca de alforria. As cartas que chegavam eram cada vez mais raras.

— O Brasil teve que recrutar escravos para lutar, — comentou seu pai, lendo o jornal. — A Princesa Isabel, novamente como regente, assinou a Lei dos Voluntários da Pátria. Escravos que servirem no Exército conquistarão a liberdade.

A guerra revelou ao mundo e aos próprios brasileiros a fragilidade de um país que dependia do braço escravo para tudo — até mesmo para defender suas fronteiras. Seis anos de conflito deixaram cicatrizes profundas na nação.

Quando Antônio finalmente retornou, em 1870, trazia no rosto as marcas da batalha e nos olhos uma nova determinação.

— Senhorita Luísa, — disse ele, com uma dignidade que impressionou a todos, — vi homens morrerem por este país. Escravos e livres, negros e brancos, todos misturados nas trincheiras. Quando lutamos lado a lado, descobrimos que somos iguais. A guerra mudou tudo.

Luísa compreendeu, naquele momento, que a escravidão tinha seus dias contados.

---

## Parte IV – Os Últimos Dias do Império

A década de 1880 trouxe ventos de transformação. O movimento abolicionista, liderado por figuras como Joaquim Nabuco e José do Patrocínio, ganhava as ruas. Advogados defendiam escravizados nos tribunais; jornais denunciavam as atrocidades do cativeiro; estudantes organizavam manifestações.

Luísa, agora uma mulher de trinta anos, participava discretamente das reuniões abolicionistas no Rio de Janeiro. Sua condição de filha de barão do café lhe dava acesso a informações e influência.

— A Lei dos Sexagenários, de 1885, libertou apenas os mais velhos — comentou um dos ativistas. — É insuficiente. Precisamos do fim total e imediato!

Em 1887, os senhores do Vale do Paraíba, incluindo o Barão de Santa Rita, perceberam que perderiam a batalha. Escravizados fugiam em massa para São Paulo, onde a Lei Áurea os aguardava. A autoridade dos senhores desmoronava.

— Meu pai está doente, — escreveu Luísa em seu diário. — Não é doença do corpo, mas da alma. Ele sabe que todo o mundo que construiu está ruindo. Mas eu... eu sinto que algo novo está nascendo.

Em 13 de maio de 1888, a notícia que mudou a história do Brasil chegou à Fazenda Santa Rita. A Princesa Isabel, agora Regente Definitiva durante a viagem de D. Pedro II à Europa, havia assinado a Lei Áurea, abolindo completamente a escravidão.

Luísa correu às senzalas, onde encontrou cenas de lágrimas, abraços e cânticos de liberdade. Antônio, o ex-soldado, ergueu os braços e exclamou:

— Finalmente! Minha mãe, meus filhos, todos livres!

Naquela noite, houve festa na fazenda — não na casa-grande, mas no terreiro, onde pela primeira vez todos celebraram como iguais.

---

## Epílogo – O Fim de uma Era

Pouco mais de um ano depois, em 15 de novembro de 1889, o Marechal Deodoro da Fonseca proclamou a República. D. Pedro II, o velho monarca que governara por quase cinquenta anos, partiu para o exílio na Europa sem resistir.

Luísa testemunhou as transformações de seu tempo: a riqueza do café que construiu um império; a guerra que revelou as contradições de uma nação escravista; a abolição que veio tarde, mas finalmente chegou; e a República que sepultou o mundo de sua infância.

Em suas memórias, escritas nos anos seguintes, ela registrou:

> *"Vivi tempos de grandeza e de vergonha, de opulência e de sofrimento. O café enriqueceu nosso país, mas foi construído sobre lágrimas. A Lei do Ventre Livre, a Guerra do Paraguai, a Lei Áurea — cada uma dessas páginas de nossa história me ensinou que as nações, como as pessoas, devem escolher que tipo de futuro desejam construir. O Brasil finalmente deu seu primeiro passo verdadeiro rumo à liberdade."*

O Segundo Reinado terminou, mas as questões que ele deixou abertas — a desigualdade, a transição para o trabalho livre, a integração dos ex-escravizados — acompanhariam o Brasil por gerações.

---

**Glossário para Estudo:**

| Termo | Significado |
|-------|-------------|
| **Segundo Reinado** | Período de 1840 a 1889, quando D. Pedro II governou o Brasil |
| **Vale do Paraíba** | Região produtora de café no século XIX, entre Rio de Janeiro e São Paulo |
| **Lei do Ventre Livre (1871)** | Declarou livres os filhos de mulheres escravizadas nascidos a partir da data |
| **Guerra do Paraguai (1864-1870)** | Conflito entre Brasil, Argentina e Uruguai contra o Paraguai |
| **Lei dos Sexagenários (1885)** | Libertou escravizados com mais de 60 anos |
| **Lei Áurea (1888)** | Abolição total da escravidão no Brasil, assinada pela Princesa Isabel |
| **Oeste Paulista** | Nova região cafeeira que substituiu o Vale do Paraíba, utilizando trabalho imigrante |

---

**Questões para Reflexão:**

1. Como a economia cafeeira transformou a sociedade brasileira durante o Segundo Reinado?
2. Por que a Lei do Ventre Livre foi considerada um passo importante, mas insuficiente, para a abolição?
3. De que forma a Guerra do Paraguai influenciou o movimento abolicionista?
4. Quais foram os interesses econômicos por trás da transição do trabalho escravo para o trabalho livre?

---

*Conto histórico educativo para preparação ENEM - História do Brasil*
