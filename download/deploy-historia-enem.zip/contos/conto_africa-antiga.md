# O Ouro de Kush

## Um conto sobre os grandes impérios da África Antiga

---

O sol despontava sobre as águas sagradas do Nilo, tingindo o céu de tons dourados e violáceos. Amenirdis, princesa do poderoso Reino de Kush, contemplava o horizonte do alto das muralhas de Meroé, a esplendorosa capital que rivalizava em grandeza com as cidades do Egito distante. Aos dezenove anos, carregava sobre os ombros a responsabilidade de uma linhagem que remontava a séculos de glória e conquistas.

— Minha filha — chamou o rei Kashta, aproximando-se com passos firmes, seus braceletes de ouro refletindo a luz da manhã. — Os mercadores nômades chegaram. Precisamos discutir os termos da nova rota comercial.

Amenirdis sabia da importância daquele momento. O comércio transaariano era a artéria vital que mantinha Kush próspera. Desde os tempos de seu avô, Piankhi, o reino expandira suas fronteiras até o Egito, e agora controlava as rotas que ligavam a África subsaariana ao Mediterrâneo. Ouro do interior do continente, marfim, ébano, peles de animais exóticos e escravos cruzavam o deserto em longas caravanas, alimentando a riqueza de Meroé.

Na grande sala do trono, decorada com hieróglifos meroíticos e estátuas de leões sagrados, os enviados dos nômades garamantes aguardavam. Eram homens de pele curtida pelo sol do deserto, vestidos com túnicas de linho fino e turbantes que protegiam do calor implacável.

— Princesa Amenirdis — saudou o chefe da caravana, um homem de barba grisalha e olhos penetrantes. — Trouxemos sal das minas de Taghaza, vidro do Mediterrâneo e tecidos de Alexandria. Em troca, desejamos o ouro de suas minas e o ferro forjado em vossos fornos.

Amenirdis manteve a expressão serena, treinada desde a infância para as negociações diplomáticas. Sabia que o ferro de Kush era cobiçado por todos os povos vizinhos. Seus artesãos dominavam técnicas avançadas de metalurgia, e as armas produzidas em Meroé eram superiores às de qualquer outro reino africano.

— O ferro de Kush não é apenas metal — respondeu com voz firme. — É o sangue de nossa terra, forjado no fogo sagrado de Apedemak, nosso deus leão. O preço será justo, mas não baixo.

A negociação durou horas. Amenirdis demonstrou conhecimento impressionante sobre os valores de cada mercadoria, surpreendendo os enviados com sua sagacidade. Quando finalmente chegaram a um acordo, o rei Kashta sorriu com orgulho.

Após a partida dos mercadores, Amenirdis reuniu-se com os sábios da corte. Entre eles estava o velho griot Mandjan, um homem vindo das terras distantes do oeste, cujas histórias atravessavam gerações.

— Princesa — disse Mandjan, sua voz rouca como o vento do deserto. — Ouroro de Kush brilha agora, mas ouvi lendas de terras além do grande deserto, onde outros impérios se erguerão. Povos que conhecerão a palavra do Profeta e construirão cidades de pedra e saber.

Amenirdis inclinou a cabeça, curiosa.

— Conta-me sobre essas terras, sábio Mandjan.

O griot fechou os olhos, como se visse através do tempo.

— Ao sul do deserto, onde o rio Níger serpenteia como uma serpente dourada, grandes reinos florescerão. O Império de Mali, governado por reis chamados mansa, será tão rico que seu ouro inundará os mercados do mundo. Um governante chamado Musa partirá em peregrinação a Meca com tantas riquezas que o preço do ouro cairá por onde passar.

Amenirdis arregalou os olhos. Mal conseguia imaginar tamanha opulência.

— E haverá mais — continuou Mandjan. — Após Mali, o Império Songai erguer-se-á como uma águia sobre as terras do Níger. Sua capital, Gao, será uma das maiores cidades do mundo. Em Tombuctu, estudiosos reunirão milhares de manuscritos, e a Universidade de Sankore atrairá sábios de todas as terras islâmicas.

A princesa de Kush sentiu o coração bater mais forte. Aquelas histórias pareciam sonhos distantes, mas o brilho nos olhos do griot revelava uma convicção profunda.

— Por que me contas isso, Mandjan?

— Porque a África é vasta, princesa. Kush é grande, mas não está sozinha. Nossos povos compartilham um legado de civilização, comércio e conhecimento. O que você aprender hoje será transmitido às gerações futuras, assim como as histórias de Mali e Songai serão passadas de pai para filho.

Nas semanas seguintes, Amenirdis acompanhou o pai em visitas às minas de ouro nas montanhas orientais. Viu de perto o trabalho árduo dos mineiros, que escavavam túneis profundos em busca do metal precioso. Observou também os fornos de ferro, onde escravos e artesãos livres trabalhavam juntos, transformando o minério bruto em armas, ferramentas e objetos de adorno.

— O povo depende de nós — disse o rei durante uma dessas visitas. — O comércio traz riqueza, mas também responsabilidade. Cada barra de ouro que enviamos ao Egito ou a Roma representa o suor de nosso povo.

Quando a época da cheia do Nilo chegou, as festividades tomaram conta de Meroé. O rio sagrado subia, fertilizando as terras agrícolas e garantindo as colheitas do ano seguinte. Amenirdis participou das cerimônias no templo de Apedemak, oferendas de incenso e libações de vinho foram derramadas diante das estátuas dos deuses.

Anos mais tarde, quando Amenirdis se tornou a poderosa Sacerdotisa de Amun e regente de Kush durante a menoridade de seu irmão, ela lembraria das palavras de Mandjan. Os impérios da África não eram ilhas isoladas, mas elos de uma grande corrente de civilização que se estendia do Nilo ao Níger, do Mediterrâneo ao Atlântico.

O ouro de Kush continuaria a fluir pelo deserto, mas o verdadeiro tesouro do continente estava em sua gente — os agricultores que cultivavam a terra negra às margens dos rios, os ferreiros que forjavam o metal, os mercadores que atravessavam o deserto, os sábios que preservavam o conhecimento em bibliotecas como a de Tombuctu.

E nas noites silenciosas, quando a lua cheia iluminava as pirâmides de Meroé, menores que as do Egito, mas não menos sagradas, Amenirdis erguia seus olhos ao céu e agradecia aos deuses por ter nascido naquela terra de ouro e ferro, onde a história da humanidade havia sido escrita muito antes de qualquer outra civilização erguer suas pedras.

*"Que as gerações futuras saibam que a África foi berço de reinos poderosos, de comércio próspero e de saber profundo. De Kush a Mali, de Mali a Songai, nosso povo sempre encontrará caminhos para a grandeza."*

---

**Fim**

---

*Nota histórica: O Reino de Kush (c. 1070 a.C. - 350 d.C.) foi uma das civilizações mais importantes da África Antiga. Localizado no atual Sudão, Kush governou o Egito durante a 25ª Dinastia. Meroé, sua capital, era um centro de produção de ferro e comércio transaariano. O Império de Mali (c. 1235-1600) ficou famoso pela riqueza de Mansa Musa I, enquanto o Império Songai (c. 1464-1591) foi o maior estado da história da África Ocidental, com Tombuctu como centro de ensino islâmico. Amenirdis I foi uma sacerdotisa real histórica, filha de Kashta.*
